#!/usr/bin/env python3
"""
================================================================================
 kenburns_parallax_moviepy.py
 Generic, config-driven Ken Burns + Parallax video renderer  (MoviePy edition)
 Built for TechWithKoushik — reusable for every future video.
================================================================================

WHY THIS EDITION
----------------
Frame math (zoom / pan / parallax) is done with NumPy + OpenCV + Pillow — the
reliable part. MoviePy + ffmpeg are used ONLY for what they do best:
  • High-quality H.264 (libx264) encoding  -> smaller, sharper, YouTube-ready
  • Smooth crossfades between slides
  • Proper audio: per-slide narration alignment + ducked background music (AAC)

It is written to run on BOTH MoviePy 2.x (current) and MoviePy 1.x via small
compatibility shims, so you won't hit the usual "set_ vs with_" breakages.

--------------------------------------------------------------------------------
INSTALL (on your machine)
--------------------------------------------------------------------------------
    pip install moviepy opencv-python numpy pillow
    # ffmpeg is required by MoviePy. Install it and make sure it's on PATH:
    #   Windows : https://www.gyan.dev/ffmpeg/builds/  (add /bin to PATH)
    #   macOS   : brew install ffmpeg
    #   Linux   : sudo apt install ffmpeg

--------------------------------------------------------------------------------
QUICK START (3 steps)
--------------------------------------------------------------------------------
1) Arrange your assets (numbers keep everything in order):
       slides/01_the_funeral.jpg
       slides/02_dissolve.jpg
       slides/03_resurrection_layers/1_bg.png     <- parallax layers (back->front)
       slides/03_resurrection_layers/2_dust.png      transparent PNGs
       slides/03_resurrection_layers/3_glasses.png
       ...
       audio/01.mp3   audio/02.mp3   ...           <- optional Edge-TTS narration

2) Auto-generate an editable config:
       python kenburns_parallax_moviepy.py init --images slides --audio audio --out config.json

3) Render everything (video + narration + optional music) in ONE go:
       python kenburns_parallax_moviepy.py render --config config.json \
              --output final.mp4 --music bg.mp3

--------------------------------------------------------------------------------
CONFIG (config.json) — only "image" is mandatory per slide
--------------------------------------------------------------------------------
{
  "settings": {
      "width": 1920, "height": 1080, "fps": 30,
      "default_duration": 6.0,
      "default_effect": "auto",     # auto|zoom_in|zoom_out|pan_left|pan_right|
                                    # pan_up|pan_down|zoom_in_pan_left|
                                    # zoom_out_pan_right|parallax
      "zoom_intensity": 0.12,
      "pan_intensity": 0.10,
      "parallax_intensity": 0.06,
      "easing": "ease_in_out",      # linear | ease_in_out
      "crossfade": 0.5,             # seconds; 0 = hard cuts
      "codec": "libx264",
      "audio_codec": "aac",
      "bitrate": "8000k",           # video bitrate; "" to let ffmpeg decide
      "music_volume": 0.12,         # background music level under narration
      "audio_tail": 0.6             # extra seconds after a narration clip
  },
  "slides": [
      {"image": "slides/01_the_funeral.jpg", "effect": "zoom_in",
       "audio": "audio/01.mp3", "focus": [0.5, 0.55]},
      {"image": "slides/03_resurrection_layers", "effect": "parallax", "duration": 7}
  ]
}
Rules:
 • Duration priority:  explicit "duration"  >  matched "audio" length + tail  >  default_duration
 • "focus":[x,y] (0..1) is where the Ken Burns move gravitates.
 • Parallax slide = "image" is a folder of PNG layers sorted back->front.
================================================================================
"""

import argparse, json, os, sys, glob, math, re
import numpy as np
import cv2
from PIL import Image

# ----------------------------------------------------------------------------
# MoviePy import with 1.x / 2.x compatibility
# ----------------------------------------------------------------------------
_MP_OK = True
try:
    # MoviePy 2.x
    from moviepy import (VideoClip, AudioFileClip, CompositeVideoClip,
                         CompositeAudioClip, concatenate_videoclips)
    try:
        from moviepy import vfx, afx
    except Exception:
        vfx = afx = None
    _MP_V2 = True
except Exception:
    try:
        # MoviePy 1.x
        from moviepy.editor import (VideoClip, AudioFileClip, CompositeVideoClip,
                                    CompositeAudioClip, concatenate_videoclips)
        try:
            from moviepy.editor import vfx, afx
        except Exception:
            vfx = afx = None
        _MP_V2 = False
    except Exception:
        _MP_OK = False
        _MP_V2 = False

# ---- tiny compatibility shims (work on both versions) ----------------------
def _mp_video(frame_func, duration):
    """Create a VideoClip from a make_frame function on either version."""
    try:
        return VideoClip(frame_function=frame_func, duration=duration)   # 2.x
    except TypeError:
        return VideoClip(make_frame=frame_func, duration=duration)       # 1.x

def _with(clip, name2, name1, *args):
    """Call with_* (2.x) or set_* (1.x) transparently."""
    if hasattr(clip, name2):
        return getattr(clip, name2)(*args)
    return getattr(clip, name1)(*args)

def _crossfadein(clip, d):
    if d <= 0:
        return clip
    try:
        if vfx is not None and hasattr(vfx, "CrossFadeIn"):
            return clip.with_effects([vfx.CrossFadeIn(d)])               # 2.x
    except Exception:
        pass
    try:
        return clip.crossfadein(d)                                       # 1.x
    except Exception:
        return clip

def _set_volume(aclip, factor):
    try:
        if afx is not None and hasattr(afx, "MultiplyVolume"):
            return aclip.with_effects([afx.MultiplyVolume(factor)])      # 2.x
    except Exception:
        pass
    try:
        return aclip.volumex(factor)                                     # 1.x
    except Exception:
        return aclip

def _loop_audio(aclip, duration):
    """Loop an audio clip to reach 'duration' (falls back to trim)."""
    try:
        if afx is not None and hasattr(afx, "AudioLoop"):
            return aclip.with_effects([afx.AudioLoop(duration=duration)])
    except Exception:
        pass
    try:
        return afx.audio_loop(aclip, duration=duration)                  # 1.x helper
    except Exception:
        pass
    # manual fallback: subclip/trim if long enough
    try:
        if aclip.duration >= duration:
            return _subclip(aclip, 0, duration)
    except Exception:
        pass
    return aclip

def _subclip(clip, start, end):
    if hasattr(clip, "subclipped"):
        return clip.subclipped(start, end)     # 2.x
    return clip.subclip(start, end)            # 1.x

def _set_start(clip, t):    return _with(clip, "with_start", "set_start", t)
def _set_audio(clip, a):    return _with(clip, "with_audio", "set_audio", a)
def _set_duration(clip, d): return _with(clip, "with_duration", "set_duration", d)
def _set_fps(clip, fps):    return _with(clip, "with_fps", "set_fps", fps)

# ----------------------------------------------------------------------------
# Image helpers
# ----------------------------------------------------------------------------
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".bmp")

def natural_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', s)]

def ease(t, mode="ease_in_out"):
    if mode == "linear":
        return t
    return t * t * (3 - 2 * t)   # smoothstep

def cover_fit(pil_img, tw, th):
    """Scale + center-crop so the image fully covers tw x th (no bars)."""
    w, h = pil_img.size
    scale = max(tw / w, th / h)
    nw, nh = int(math.ceil(w * scale)), int(math.ceil(h * scale))
    pil_img = pil_img.resize((nw, nh), Image.LANCZOS)
    left, top = (nw - tw) // 2, (nh - th) // 2
    return pil_img.crop((left, top, left + tw, top + th))

def load_bgr(path, tw, th):
    img = Image.open(path).convert("RGB")
    img = cover_fit(img, tw, th)
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def get_audio_duration(path):
    if not path or not os.path.exists(path) or not _MP_OK:
        return None
    try:
        a = AudioFileClip(path)
        d = float(a.duration)
        a.close()
        return d
    except Exception:
        return None

# ----------------------------------------------------------------------------
# Effect decoding
# ----------------------------------------------------------------------------
AUTO_CYCLE = ["zoom_in", "pan_right", "zoom_out", "pan_left",
              "zoom_in_pan_left", "pan_up", "zoom_out_pan_right", "pan_down"]

def resolve_effect(slide, idx, default_effect):
    eff = slide.get("effect", default_effect)
    img = slide["image"]
    is_layers = os.path.isdir(img) or img.rstrip("/\\").endswith("_layers")
    if eff in (None, "auto"):
        return "parallax" if is_layers else AUTO_CYCLE[idx % len(AUTO_CYCLE)]
    return eff

def decode_move(effect, zoom, pan):
    """Return (z0,z1,px0,px1,py0,py1) for a Ken Burns effect string."""
    z0 = z1 = 1.0
    px0 = px1 = py0 = py1 = 0.0
    if "zoom_in" in effect:   z0, z1 = 1.0, 1.0 + zoom
    if "zoom_out" in effect:  z0, z1 = 1.0 + zoom, 1.0
    if "pan_left" in effect:  px0, px1 = pan, -pan
    if "pan_right" in effect: px0, px1 = -pan, pan
    if "pan_up" in effect:    py0, py1 = pan, -pan
    if "pan_down" in effect:  py0, py1 = -pan, pan
    if z0 == z1 == 1.0 and px0 == px1 == py0 == py1 == 0.0:
        z0, z1 = 1.0, 1.0 + zoom   # safe fallback = gentle zoom in
    return z0, z1, px0, px1, py0, py1

# ----------------------------------------------------------------------------
# Per-slide make_frame builders (return RGB uint8 for MoviePy)
# ----------------------------------------------------------------------------
def build_kenburns_maker(path, effect, s, focus, duration):
    W, H = s["width"], s["height"]
    zoom, pan, easing = s["zoom_intensity"], s["pan_intensity"], s["easing"]
    fx, fy = focus
    z0, z1, px0, px1, py0, py1 = decode_move(effect, zoom, pan)

    # Oversized canvas so panning/zooming never reveals empty edges.
    head = 1.0 + max(zoom, pan) + 0.02
    big_w, big_h = int(W * head), int(H * head)
    base = load_bgr(path, W, H)
    big = cv2.resize(base, (big_w, big_h), interpolation=cv2.INTER_LANCZOS4)

    def make_frame(t):
        t01 = 0.0 if duration <= 0 else min(1.0, max(0.0, t / duration))
        te = ease(t01, easing)
        z = z0 + (z1 - z0) * te
        ox = px0 + (px1 - px0) * te
        oy = py0 + (py1 - py0) * te
        cw, ch = W / z, H / z
        cx = big_w * (0.5 + (fx - 0.5) * 0.5) + ox * W
        cy = big_h * (0.5 + (fy - 0.5) * 0.5) + oy * H
        x0 = int(np.clip(cx - cw / 2, 0, big_w - cw))
        y0 = int(np.clip(cy - ch / 2, 0, big_h - ch))
        crop = big[y0:y0 + int(ch), x0:x0 + int(cw)]
        frame = cv2.resize(crop, (W, H), interpolation=cv2.INTER_LANCZOS4)
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    return make_frame

def build_parallax_maker(folder, s, duration):
    W, H = s["width"], s["height"]
    intensity, easing = s["parallax_intensity"], s["easing"]
    head = 0.12
    bw, bh = int(W * (1 + head)), int(H * (1 + head))

    files = [f for f in sorted(os.listdir(folder), key=natural_key)
             if f.lower().endswith((".png", ".webp"))]
    if not files:
        raise ValueError(f"No PNG/WebP layers found in '{folder}'")
    layers = []
    for f in files:
        im = Image.open(os.path.join(folder, f)).convert("RGBA")
        im = cover_fit(im, bw, bh)
        arr = np.array(im)
        rgb = cv2.cvtColor(arr[:, :, :3], cv2.COLOR_RGB2BGR)
        alpha = arr[:, :, 3:4].astype(np.float32) / 255.0
        layers.append((rgb, alpha))
    speeds = np.linspace(0.25, 1.0, len(layers)) * intensity

    def make_frame(t):
        t01 = 0.0 if duration <= 0 else min(1.0, max(0.0, t / duration))
        te = ease(t01, easing)
        base_x = te - 0.5
        canvas = np.zeros((H, W, 3), dtype=np.uint8)
        for (rgb, alpha), spd in zip(layers, speeds):
            dx = int(base_x * spd * W)
            dy = int(base_x * spd * H * 0.4)
            x0 = int(np.clip((bw - W) / 2 + dx, 0, bw - W))
            y0 = int(np.clip((bh - H) / 2 + dy, 0, bh - H))
            sub_rgb = rgb[y0:y0 + H, x0:x0 + W]
            sub_a = alpha[y0:y0 + H, x0:x0 + W]
            canvas = (sub_rgb * sub_a + canvas * (1 - sub_a)).astype(np.uint8)
        return cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)

    return make_frame

# ----------------------------------------------------------------------------
# Config defaults
# ----------------------------------------------------------------------------
def fill_defaults(s):
    d = {
        "width": 1920, "height": 1080, "fps": 30,
        "default_duration": 6.0, "default_effect": "auto",
        "zoom_intensity": 0.12, "pan_intensity": 0.10,
        "parallax_intensity": 0.06, "easing": "ease_in_out",
        "crossfade": 0.5, "codec": "libx264", "audio_codec": "aac",
        "bitrate": "8000k", "music_volume": 0.12, "audio_tail": 0.6,
    }
    for k, v in d.items():
        s.setdefault(k, v)
    return s

# ----------------------------------------------------------------------------
# Commands
# ----------------------------------------------------------------------------
def cmd_init(args):
    imgs = []
    for ext in IMAGE_EXTS:
        imgs += glob.glob(os.path.join(args.images, f"*{ext}"))
    layer_dirs = [d for d in glob.glob(os.path.join(args.images, "*_layers"))
                  if os.path.isdir(d)]
    entries = sorted(imgs, key=natural_key) + sorted(layer_dirs, key=natural_key)
    if not entries:
        print(f"No images found in {args.images}")
        sys.exit(1)

    slides = []
    for path in entries:
        slide = {"image": path, "effect": "auto"}
        if args.audio:
            m = re.match(r"(\d+)", os.path.basename(path))
            if m:
                for ext in (".mp3", ".wav", ".m4a", ".aac"):
                    cand = os.path.join(args.audio, f"{m.group(1)}{ext}")
                    if os.path.exists(cand):
                        slide["audio"] = cand
                        break
        slides.append(slide)

    cfg = {"settings": fill_defaults({}), "slides": slides}
    with open(args.out, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"✅ Wrote {args.out} with {len(slides)} slides. Edit it, then run 'render'.")

def cmd_render(args):
    if not _MP_OK:
        print("ERROR: MoviePy is not installed. Run:  pip install moviepy")
        sys.exit(1)

    with open(args.config) as f:
        cfg = json.load(f)
    s = fill_defaults(cfg.get("settings", {}))
    W, H, fps = s["width"], s["height"], s["fps"]
    slides = cfg["slides"]
    if not slides:
        print("No slides in config."); sys.exit(1)

    # ---- resolve durations first (needed for audio alignment) ----
    durations = []
    for sl in slides:
        dur = sl.get("duration")
        if dur is None:
            adur = get_audio_duration(sl.get("audio"))
            dur = (adur + s["audio_tail"]) if adur is not None else s["default_duration"]
        durations.append(max(0.2, float(dur)))

    # crossfade cannot exceed half of the shortest neighbouring slide
    xfade = float(s["crossfade"])
    if xfade > 0 and len(slides) > 1:
        xfade = min(xfade, min(durations) / 2.0)

    # ---- build video clips ----
    clips = []
    for idx, sl in enumerate(slides):
        effect = resolve_effect(sl, idx, s["default_effect"])
        dur = durations[idx]
        focus = sl.get("focus", [0.5, 0.5])
        print(f"[{idx+1}/{len(slides)}] {os.path.basename(str(sl['image']))}  "
              f"effect={effect}  dur={dur:.2f}s")

        if effect == "parallax":
            maker = build_parallax_maker(sl["image"], s, dur)
        else:
            maker = build_kenburns_maker(sl["image"], effect, s, focus, dur)

        clip = _mp_video(maker, dur)
        clip = _set_fps(clip, fps)
        if idx > 0:
            clip = _crossfadein(clip, xfade)
        clips.append(clip)

    # ---- concatenate (compose + negative padding = crossfade) ----
    if xfade > 0 and len(clips) > 1:
        try:
            video = concatenate_videoclips(clips, method="compose", padding=-xfade)
        except TypeError:
            # older signature without padding kw
            video = concatenate_videoclips(clips, method="compose")
    else:
        video = concatenate_videoclips(clips, method="compose")

    total = float(video.duration)

    # ---- assemble audio ----
    audio_layers = []
    # narration aligned to slide starts
    start = 0.0
    starts = []
    for i, dur in enumerate(durations):
        starts.append(start)
        start += dur - (xfade if (xfade > 0 and i < len(durations) - 1) else 0.0)

    for sl, st in zip(slides, starts):
        ap = sl.get("audio")
        if ap and os.path.exists(ap):
            try:
                a = AudioFileClip(ap)
                a = _set_start(a, max(0.0, st))
                audio_layers.append(a)
            except Exception as e:
                print(f"  ⚠️ could not load audio {ap}: {e}")

    # optional background music, looped/trimmed to total & ducked
    if args.music and os.path.exists(args.music):
        try:
            music = AudioFileClip(args.music)
            music = _loop_audio(music, total)
            try:
                music = _subclip(music, 0, total)
            except Exception:
                pass
            music = _set_volume(music, s["music_volume"])
            music = _set_start(music, 0.0)
            audio_layers.append(music)
        except Exception as e:
            print(f"  ⚠️ could not load music {args.music}: {e}")

    if audio_layers:
        try:
            comp = CompositeAudioClip(audio_layers)
            comp = _set_duration(comp, total)
            video = _set_audio(video, comp)
        except Exception as e:
            print(f"  ⚠️ audio compositing failed, exporting silent video: {e}")

    # ---- export ----
    write_kwargs = dict(fps=fps, codec=s["codec"], audio_codec=s["audio_codec"],
                        threads=args.threads, preset=args.preset)
    if s.get("bitrate"):
        write_kwargs["bitrate"] = s["bitrate"]
    # drop kwargs unsupported by very old versions gracefully
    try:
        video.write_videofile(args.output, **write_kwargs)
    except TypeError:
        write_kwargs.pop("preset", None)
        write_kwargs.pop("threads", None)
        video.write_videofile(args.output, **write_kwargs)

    print(f"✅ Done -> {args.output}  ({total:.1f}s, {W}x{H}@{fps})")

# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Ken Burns + Parallax renderer (MoviePy)")
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("init", help="auto-generate config.json from a folder")
    pi.add_argument("--images", required=True)
    pi.add_argument("--audio", default=None)
    pi.add_argument("--out", default="config.json")
    pi.set_defaults(func=cmd_init)

    pr = sub.add_parser("render", help="render video + narration (+ music)")
    pr.add_argument("--config", required=True)
    pr.add_argument("--output", default="final.mp4")
    pr.add_argument("--music", default=None, help="background music file (optional)")
    pr.add_argument("--threads", type=int, default=4)
    pr.add_argument("--preset", default="medium",
                    help="x264 preset: ultrafast..veryslow (slower=smaller file)")
    pr.set_defaults(func=cmd_render)

    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
